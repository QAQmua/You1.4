// 📄 替换文件：33.swiftpm/微信/WeChatViewModel.swift
import SwiftUI

// 1. 定义聊天数据的结构 (加入未读数)
struct ChatModel: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let message: String
    let time: String
    let avatarColor: Color
    var unreadCount: Int = 0 // 🌟 新增：未读消息数
}

// 2. 微信的数据管理中心
class WeChatViewModel: ObservableObject {
    @Published var chatList: [ChatModel] = [
        ChatModel(name: "文件传输助手", message: "[图片]", time: "19:18", avatarColor: .green),
        ChatModel(name: "张三", message: "晚上吃什么？", time: "18:00", avatarColor: .orange, unreadCount: 2),
        ChatModel(name: "微信运动", message: "[应用消息]", time: "17:30", avatarColor: .blue),
        ChatModel(name: "李四", message: "那个 bug 修好了吗？", time: "昨天", avatarColor: .cyan),
        ChatModel(name: "相亲相爱一家人", message: "老妈：回家吃饭啦", time: "星期二", avatarColor: .pink, unreadCount: 15)
    ]
    
    // 如果以后要加发送消息功能，就写在这里
    func sendMessage(to name: String, text: String) {
        let newMessage = ChatModel(
            name: name,
            message: text,
            time: "刚刚",
            avatarColor: .green,
            unreadCount: 0
        )
        // 将新消息插入到列表最前面
        chatList.insert(newMessage, at: 0)
    }
}
