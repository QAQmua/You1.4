// 📄 替换文件：33.swiftpm/微信/WeChatDiscoverView.swift
import SwiftUI

struct WeChatDiscoverView: View {
    var body: some View {
        List {
            // 第 1 组：朋友圈
            Section {
                discoverRow(icon: "camera.aperture", color: .blue, title: "朋友圈")
            }
            
            // 第 2 组：视频号、直播
            Section {
                discoverRow(icon: "video.badge.checkmark", color: .orange, title: "视频号")
                discoverRow(icon: "play.tv.fill", color: .red, title: "直播")
            }
            
            // 第 3 组：扫一扫、摇一摇
            Section {
                discoverRow(icon: "qrcode.viewfinder", color: .blue, title: "扫一扫")
                discoverRow(icon: "iphone.radiowaves.left.and.right", color: .blue, title: "摇一摇")
            }
            
            // 第 4 组：看一看、搜一搜
            Section {
                discoverRow(icon: "eye.fill", color: .yellow, title: "看一看")
                discoverRow(icon: "magnifyingglass.circle.fill", color: .red, title: "搜一搜")
            }
            
            // 第 5 组：小程序
            Section {
                discoverRow(icon: "circle.grid.2x2.fill", color: .purple, title: "小程序")
            }
        }
        // 🌟 微信“发现”页的经典底色样式
        .listStyle(.insetGrouped) 
    }
    
    // 抽象出统一的行 UI
    private func discoverRow(icon: String, color: Color, title: String) -> some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.system(size: 18))
                .frame(width: 28, height: 28)
            Text(title.tr)
                .font(.system(size: 16))
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 14))
                .foregroundColor(.gray.opacity(0.6))
        }
        .padding(.vertical, 4)
    }
}
