// 📄 文件名：ContentView.swift (全选替换)
import SwiftUI

// MARK: - 全局根入口
struct ContentView: View {
    @State private var isUnlocked = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if isUnlocked {
                HomeScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            } else {
                LockScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            }
        }
    }
}
